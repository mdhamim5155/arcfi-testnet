// JavaScript Logic remains exactly as in your provided code
    const CONFIG = {
        arc: {
            chainId: '0x4cecd2', // 5042002
            name: 'Arc Testnet',
            rpc: 'https://rpc.testnet.arc.network',
            explorer: 'https://testnet.arcscan.app',
            usdc: '0x3600000000000000000000000000000000000000'
        },
        sep: { chainId: '0xaa36a7', name: 'Sepolia' }
    };

    let provider, signer, address;
    let store = JSON.parse(localStorage.getItem('arcfi_v1') || '{"pts":0,"streak":0,"lastCi":"","txs":[]}');

    async function connect() {
        if (!window.ethereum) return toast("Please install MetaMask");
        try {
            provider = new ethers.providers.Web3Provider(window.ethereum);
            const accounts = await provider.send("eth_requestAccounts", []);
            address = accounts[0];
            signer = provider.getSigner();
            const net = await provider.getNetwork();
            if (net.chainId !== 5042002) await switchNet(CONFIG.arc);
            document.getElementById('wBtn').innerText = address.slice(0,6)+'...'+address.slice(-4);
            updateUI();
            toast("Wallet Connected", "success");
        } catch (e) { toast("Connection Failed"); }
    }

    async function switchNet(cfg) {
        try {
            await window.ethereum.request({
                method: 'wallet_switchEthereumChain',
                params: [{ chainId: cfg.chainId }],
            });
        } catch (e) {
            if (e.code === 4902) {
                await window.ethereum.request({
                    method: 'wallet_addEthereumChain',
                    params: [{
                        chainId: cfg.chainId,
                        chainName: cfg.name,
                        nativeCurrency: { name: 'USDC', symbol: 'USDC', decimals: 18 },
                        rpcUrls: [cfg.rpc],
                        blockExplorerUrls: [cfg.explorer]
                    }]
                });
            }
        }
    }

    async function updateUI() {
        if (!address) return;
        const bal = await provider.getBalance(address);
        const fmtBal = parseFloat(ethers.utils.formatEther(bal)).toFixed(4);
        document.getElementById('mainBal').innerHTML = `${fmtBal} <span style="font-size:1.5rem; color:var(--text3)">USDC</span>`;
        document.getElementById('portfolio').innerHTML = `<div style="display:flex; justify-content:space-between; padding:10px 0; border-bottom:1px solid var(--border)"><span>Native USDC</span><b>${fmtBal}</b></div>`;
        document.getElementById('ptsVal').innerText = store.pts;
        document.getElementById('streakVal').innerText = store.streak;
        renderHistory();
    }

    // ACTIONS (Send, CheckIn, Bridge, Swap, Deploy)
    async function doSend() {
        const to = document.getElementById('sTo').value;
        const amt = document.getElementById('sAmt').value;
        if (!ethers.utils.isAddress(to) || !amt) return toast("Invalid Details");
        try {
            toast("Confirm in Wallet...");
            const tx = await signer.sendTransaction({ to, value: ethers.utils.parseEther(amt) });
            addTx("Send", `To ${to.slice(0,6)}`, amt, tx.hash);
            await tx.wait();
            toast("Sent Successfully!");
            addPts(5); updateUI();
        } catch (e) { toast("Transaction Failed"); }
    }

    async function doCheckIn() {
        const today = new Date().toDateString();
        if (store.lastCi === today) return toast("Already Claimed Today");
        try {
            toast("Sending proof transaction...");
            const tx = await signer.sendTransaction({ to: address, value: 0 });
            await tx.wait();
            store.streak++;
            store.lastCi = today;
            addPts(10);
            addTx("Check-In", "Daily streak reward", "0", tx.hash);
            save(); updateUI();
            toast("Check-in Success!");
        } catch (e) { toast("Check-in Failed"); }
    }

    async function doBridge() {
        const amt = document.getElementById('brA').value;
        if (!amt) return toast("Enter amount");
        try {
            await switchNet(CONFIG.sep);
            const tx = await signer.sendTransaction({ to: address, value: ethers.utils.parseEther(amt) });
            await tx.wait();
            await switchNet(CONFIG.arc);
            addPts(15);
            addTx("Bridge", "Sepolia to Arc", amt, tx.hash);
            updateUI();
        } catch (e) { toast("Bridge Failed"); }
    }

    async function doSwap() {
        const amt = document.getElementById('swI').value;
        if (!amt) return toast("Enter amount");
        try {
            toast("Signing Swap...");
            const tx = await signer.sendTransaction({ to: address, value: 0 });
            await tx.wait();
            addPts(3);
            addTx("Swap", `${document.getElementById('swF').value} to ${document.getElementById('swT').value}`, amt, tx.hash);
            toast("Swap Confirmed!");
            updateUI();
        } catch (e) { toast("Swap Failed"); }
    }

    async function doDeploy() {
        const name = document.getElementById('depN').value || "MyContract";
        try {
            toast("Deploying Smart Contract...");
            const tx = await signer.sendTransaction({ data: "0x6080604052348015600f57600080fd5b50603e80601d6000396000f3fe" });
            await tx.wait();
            addPts(50);
            addTx("Deploy", name, "0", tx.hash);
            toast("Deployed Successfully!");
            updateUI();
        } catch (e) { toast("Deployment Failed"); }
    }

    function addPts(n) { store.pts += n; save(); }
    function addTx(type, desc, amt, hash) {
        store.txs.unshift({ type, desc, amt, hash, time: new Date().toLocaleTimeString() });
        if (store.txs.length > 10) store.txs.pop();
        save();
    }
    function renderHistory() {
        const container = document.getElementById('recentHist');
        if (store.txs.length === 0) return;
        container.innerHTML = store.txs.map(tx => `<div style="display:flex; justify-content:space-between; align-items:center; padding:12px 0; border-bottom:1px solid var(--border)"><div><div style="font-weight:600; font-size:0.85rem;">${tx.type}</div><div style="font-size:0.7rem; color:var(--text3);">${tx.desc}</div></div><div style="text-align:right"><div style="font-weight:700; font-size:0.85rem;">${tx.amt} USDC</div><a href="${CONFIG.arc.explorer}/tx/${tx.hash}" target="_blank" style="font-size:0.65rem; color:var(--blue); text-decoration:none;">View ↗</a></div></div>`).join('');
    }
    function save() { localStorage.setItem('arcfi_v1', JSON.stringify(store)); }

    function nav(id) {
        document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
        document.getElementById('page-' + id).classList.add('active');
        document.getElementById('pageTitle').innerText = id.charAt(0).toUpperCase() + id.slice(1);
        document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
        const activeNav = document.getElementById('nav-' + id);
        if (activeNav) activeNav.classList.add('active');
        if (window.innerWidth < 900) toggleMenu();
    }

    function toggleMenu() {
        document.getElementById('sidebar').classList.toggle('open');
        document.getElementById('overlay').classList.toggle('open');
    }

    function toggleTheme() {
        const current = document.documentElement.getAttribute('data-theme');
        const next = current === 'dark' ? 'light' : 'dark';
        document.documentElement.setAttribute('data-theme', next);
        document.getElementById('themeIcon').innerText = next === 'dark' ? '🌙' : '☀️';
    }

    function toast(msg) {
        const t = document.getElementById('toast');
        t.innerText = msg; t.style.display = 'block';
        setTimeout(() => t.style.display = 'none', 3000);
    }
    setInterval(() => { document.getElementById('gasStatus').innerText = `GAS: ${(Math.random()*5+10).toFixed(1)} Gwei`; }, 4000);
    if (window.ethereum) connect();