# ArcFi Dashboard

## Deploy on GitHub Pages

1. Upload all files to a GitHub repository
2. Go to Settings → Pages
3. Source → Deploy from branch
4. Select:
   - Branch: main
   - Folder: /root
5. Save

Live URL:
https://USERNAME.github.io/REPO/
